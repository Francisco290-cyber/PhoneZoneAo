#!/usr/bin/env python3
"""
Script de setup automático do PhoneZone AO
Executa: python setup.py
"""

import os
import sys
import subprocess
import platform

def run(cmd, check=True):
    print(f"  → {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if check and result.returncode != 0:
        print(f"  ❌ Erro: {result.stderr}")
        return False
    if result.stdout:
        print(f"     {result.stdout.strip()}")
    return True

def main():
    print("\n" + "="*50)
    print("  📱 PhoneZone AO — Setup Automático")
    print("="*50 + "\n")

    IS_WIN = platform.system() == "Windows"

    # 1. Criar venv
    print("1️⃣  Criar ambiente virtual...")
    if not os.path.exists("venv"):
        run(f"{sys.executable} -m venv venv")
    else:
        print("  ✓ venv já existe")

    # 2. Caminho do pip dentro do venv
    if IS_WIN:
        pip = "venv\\Scripts\\pip"
        python = "venv\\Scripts\\python"
    else:
        pip = "venv/bin/pip"
        python = "venv/bin/python"

    # 3. Instalar dependências
    print("\n2️⃣  Instalar dependências...")
    run(f"{pip} install -r requirements.txt")

    # 4. Verificar .env
    print("\n3️⃣  Verificar .env...")
    if os.path.exists(".env"):
        print("  ✓ .env existe — edita DATABASE_URL e SECRET_KEY")
    else:
        print("  ❌ .env não encontrado")

    # 5. Flask DB
    print("\n4️⃣  Inicializar base de dados...")
    env_vars = "set FLASK_APP=run.py && " if IS_WIN else "FLASK_APP=run.py "
    if not os.path.exists("migrations"):
        run(f"{env_vars}{python} -m flask db init")
    run(f"{env_vars}{python} -m flask db migrate -m 'init'")
    run(f"{env_vars}{python} -m flask db upgrade")

    # 6. Abrir no VS Code
    print("\n5️⃣  Abrir no VS Code...")
    vscode_ok = run("code .", check=False)
    if not vscode_ok:
        print("  ⚠️  VS Code não encontrado no PATH")
        print("     Abre manualmente: File > Open Folder")

    print("\n" + "="*50)
    print("  ✅ Setup concluído!")
    print("="*50)
    print(f"\n  ▶️  Para arrancar o servidor:")
    if IS_WIN:
        print(f"      venv\\Scripts\\activate")
    else:
        print(f"      source venv/bin/activate")
    print(f"      python run.py")
    print(f"\n  🌐  Acede em: http://localhost:5000\n")

if __name__ == "__main__":
    main()

# 📱 PhoneZone AO

Marketplace especializado em telemóveis para Angola.
Construído com Flask + PostgreSQL.

---

## 🚀 Instalação rápida

### 1. Abrir no VS Code
```bash
code phonezone
```

### 2. Criar ambiente virtual
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate
```

### 3. Instalar dependências
```bash
pip install -r requirements.txt
```

### 4. Configurar base de dados
Edita o ficheiro `.env`:
```
DATABASE_URL=postgresql://SEU_USER:SUA_PASSWORD@localhost/phonezone_db
SECRET_KEY=uma-chave-secreta-longa
```

Criar a base de dados no PostgreSQL:
```sql
CREATE DATABASE phonezone_db;
```

### 5. Executar migrações
```bash
flask db init
flask db migrate -m "init"
flask db upgrade
```

### 6. Criar conta Admin (no terminal Python)
```bash
python
>>> from app import create_app
>>> from app.extensions import db
>>> from app.models.user import User
>>> app = create_app()
>>> with app.app_context():
...     admin = User(nome='Admin', email='admin@phonezone.ao', tipo='admin')
...     admin.set_password('admin123')
...     db.session.add(admin)
...     db.session.commit()
```

### 7. Arrancar o servidor
```bash
python run.py
```

Abre o browser em: **http://localhost:5000**

---

## 🏗️ Estrutura do projeto

```
phonezone/
├── app/
│   ├── models/          # Base de dados
│   │   ├── user.py      # Utilizadores (cliente/vendedor/admin)
│   │   ├── product.py   # Telemóveis
│   │   ├── message.py   # Chat
│   │   └── subscription.py  # Mensalidades
│   ├── routes/          # Lógica de negócio
│   │   ├── auth.py      # Login / Registo
│   │   ├── client.py    # Homepage, detalhe produto
│   │   ├── seller.py    # Painel do vendedor
│   │   ├── admin.py     # Painel admin
│   │   └── chat.py      # Sistema de mensagens
│   ├── templates/       # HTML
│   └── static/          # CSS, JS, Imagens
├── config.py
├── run.py
└── requirements.txt
```

---

## 💰 Modelo de negócio

| Fonte         | Valor       |
|---------------|-------------|
| Mensalidade vendedor | 5.000 Kz/mês |
| Destaque anúncio | Extra (a definir) |
| Futuro: comissão | % por venda |

---

## 👥 Tipos de utilizador

- **Cliente** — Vê produtos, contacta vendedores via chat
- **Vendedor** — Paga mensalidade, publica produtos, responde mensagens
- **Admin** — Aprova vendedores, gere plataforma

---

## 🛠️ Tecnologias

- **Backend:** Flask 3.0
- **Base de dados:** PostgreSQL + SQLAlchemy
- **Autenticação:** Flask-Login
- **Migrações:** Flask-Migrate
- **Chat:** Fetch API + polling (3s)
- **Imagens:** Pillow (redimensionamento automático)
- **Frontend:** HTML + CSS custom + JS vanilla

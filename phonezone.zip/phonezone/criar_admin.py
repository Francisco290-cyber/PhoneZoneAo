"""
Cria o primeiro utilizador Admin
Executa: python criar_admin.py
"""
from app import create_app
from app.extensions import db
from app.models.user import User

app = create_app()

with app.app_context():
    email = input("Email do admin: ").strip()
    nome = input("Nome: ").strip()
    password = input("Password: ").strip()

    if User.query.filter_by(email=email).first():
        print("❌ Email já existe.")
    else:
        admin = User(nome=nome, email=email, tipo='admin')
        admin.set_password(password)
        db.session.add(admin)
        db.session.commit()
        print(f"✅ Admin '{nome}' criado com sucesso!")

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from app.extensions import db
from app.models.user import User
from app.models.subscription import Subscription
from config import Config

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('client.home'))

    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()

        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            if user.is_admin():
                return redirect(next_page or url_for('admin.dashboard'))
            elif user.is_vendedor():
                return redirect(next_page or url_for('seller.dashboard'))
            else:
                return redirect(next_page or url_for('client.home'))
        else:
            flash('Email ou password incorretos.', 'danger')

    return render_template('auth/login.html')


@auth_bp.route('/registar', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('client.home'))

    if request.method == 'POST':
        nome = request.form.get('nome')
        email = request.form.get('email')
        telefone = request.form.get('telefone')
        password = request.form.get('password')
        tipo = request.form.get('tipo', 'cliente')

        if User.query.filter_by(email=email).first():
            flash('Este email já está registado.', 'danger')
            return redirect(url_for('auth.register'))

        user = User(nome=nome, email=email, telefone=telefone, tipo=tipo)
        user.set_password(password)
        db.session.add(user)

        # Se vendedor, criar subscricao pendente
        if tipo == 'vendedor':
            sub = Subscription(vendedor_id=None, valor=Config.MENSALIDADE_VALOR)
            db.session.flush()  # para obter user.id
            sub.vendedor_id = user.id
            db.session.add(sub)

        db.session.commit()
        flash('Conta criada com sucesso! Faz login.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('auth/register.html')


@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('client.home'))

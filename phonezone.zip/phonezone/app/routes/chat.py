from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from app.extensions import db
from app.models.message import Message
from app.models.user import User
from app.models.product import Product

chat_bp = Blueprint('chat', __name__)


@chat_bp.route('/<int:vendedor_id>')
@login_required
def chat(vendedor_id):
    vendedor = User.query.get_or_404(vendedor_id)
    produto_id = request.args.get('produto_id', type=int)
    produto = Product.query.get(produto_id) if produto_id else None

    # Marcar mensagens como lidas
    Message.query.filter_by(
        remetente_id=vendedor_id,
        destinatario_id=current_user.id,
        lida=False
    ).update({'lida': True})
    db.session.commit()

    # Buscar histórico
    mensagens = Message.query.filter(
        db.or_(
            db.and_(Message.remetente_id == current_user.id,
                    Message.destinatario_id == vendedor_id),
            db.and_(Message.remetente_id == vendedor_id,
                    Message.destinatario_id == current_user.id)
        )
    ).order_by(Message.criado_em.asc()).all()

    return render_template('chat/chat.html',
                           vendedor=vendedor,
                           produto=produto,
                           mensagens=mensagens)


@chat_bp.route('/enviar', methods=['POST'])
@login_required
def send_message():
    data = request.get_json()
    destinatario_id = data.get('destinatario_id')
    conteudo = data.get('conteudo', '').strip()
    produto_id = data.get('produto_id')

    if not conteudo or not destinatario_id:
        return jsonify({'erro': 'Dados inválidos'}), 400

    msg = Message(
        conteudo=conteudo,
        remetente_id=current_user.id,
        destinatario_id=destinatario_id,
        produto_id=produto_id
    )
    db.session.add(msg)
    db.session.commit()

    return jsonify({
        'id': msg.id,
        'conteudo': msg.conteudo,
        'remetente_id': msg.remetente_id,
        'criado_em': msg.criado_em.strftime('%H:%M')
    })


@chat_bp.route('/mensagens/<int:vendedor_id>')
@login_required
def get_messages(vendedor_id):
    ultimo_id = request.args.get('ultimo_id', 0, type=int)

    mensagens = Message.query.filter(
        db.or_(
            db.and_(Message.remetente_id == current_user.id,
                    Message.destinatario_id == vendedor_id),
            db.and_(Message.remetente_id == vendedor_id,
                    Message.destinatario_id == current_user.id)
        ),
        Message.id > ultimo_id
    ).order_by(Message.criado_em.asc()).all()

    # Marcar como lidas
    for m in mensagens:
        if m.destinatario_id == current_user.id:
            m.lida = True
    db.session.commit()

    return jsonify([{
        'id': m.id,
        'conteudo': m.conteudo,
        'remetente_id': m.remetente_id,
        'criado_em': m.criado_em.strftime('%H:%M')
    } for m in mensagens])

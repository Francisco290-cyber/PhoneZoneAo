from flask import Blueprint, render_template, request
from app.models.product import Product

client_bp = Blueprint('client', __name__)


@client_bp.route('/')
def home():
    search = request.args.get('search', '')
    marca = request.args.get('marca', '')
    estado = request.args.get('estado', '')
    page = request.args.get('page', 1, type=int)

    query = Product.query.filter_by(ativo=True, aprovado=True)

    if search:
        query = query.filter(Product.nome.ilike(f'%{search}%'))
    if marca:
        query = query.filter(Product.marca.ilike(f'%{marca}%'))
    if estado:
        query = query.filter_by(estado=estado)

    destaques = Product.query.filter_by(ativo=True, aprovado=True, destaque=True).limit(4).all()
    produtos = query.order_by(Product.criado_em.desc()).paginate(page=page, per_page=12)

    return render_template('client/home.html', produtos=produtos, destaques=destaques,
                           search=search, marca=marca, estado=estado)


@client_bp.route('/produto/<int:id>')
def product_detail(id):
    produto = Product.query.get_or_404(id)
    # Outros produtos do mesmo vendedor
    relacionados = Product.query.filter_by(
        vendedor_id=produto.vendedor_id, ativo=True
    ).filter(Product.id != id).limit(4).all()
    return render_template('client/product_detail.html', produto=produto, relacionados=relacionados)

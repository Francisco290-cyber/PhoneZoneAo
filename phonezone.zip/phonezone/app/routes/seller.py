from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from app.extensions import db
from app.models.product import Product
from app.models.message import Message
from functools import wraps
import os
import uuid
from PIL import Image

seller_bp = Blueprint('seller', __name__)


def vendedor_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_vendedor():
            flash('Acesso apenas para vendedores.', 'danger')
            return redirect(url_for('client.home'))
        return f(*args, **kwargs)
    return decorated


def allowed_file(filename):
    return '.' in filename and \
        filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']


def save_image(file):
    ext = file.filename.rsplit('.', 1)[1].lower()
    filename = f"{uuid.uuid4().hex}.{ext}"
    filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)

    img = Image.open(file)
    img.thumbnail((800, 800))
    img.save(filepath, optimize=True, quality=85)

    return filename


@seller_bp.route('/dashboard')
@login_required
@vendedor_required
def dashboard():
    produtos = Product.query.filter_by(vendedor_id=current_user.id).order_by(
        Product.criado_em.desc()).all()
    # Mensagens não lidas
    nao_lidas = Message.query.filter_by(
        destinatario_id=current_user.id, lida=False).count()
    return render_template('seller/dashboard.html', produtos=produtos, nao_lidas=nao_lidas)


@seller_bp.route('/produto/adicionar', methods=['GET', 'POST'])
@login_required
@vendedor_required
def add_product():
    if request.method == 'POST':
        imagem_filename = None
        if 'imagem' in request.files:
            file = request.files['imagem']
            if file and file.filename and allowed_file(file.filename):
                imagem_filename = save_image(file)

        produto = Product(
            nome=request.form.get('nome'),
            descricao=request.form.get('descricao'),
            preco=int(request.form.get('preco', 0)),
            estado=request.form.get('estado', 'usado'),
            marca=request.form.get('marca'),
            modelo=request.form.get('modelo'),
            armazenamento=request.form.get('armazenamento'),
            cor=request.form.get('cor'),
            imagem=imagem_filename,
            vendedor_id=current_user.id
        )
        db.session.add(produto)
        db.session.commit()
        flash('Produto publicado com sucesso!', 'success')
        return redirect(url_for('seller.dashboard'))

    return render_template('seller/add_product.html')


@seller_bp.route('/produto/editar/<int:id>', methods=['GET', 'POST'])
@login_required
@vendedor_required
def edit_product(id):
    produto = Product.query.get_or_404(id)
    if produto.vendedor_id != current_user.id:
        flash('Não tens permissão.', 'danger')
        return redirect(url_for('seller.dashboard'))

    if request.method == 'POST':
        produto.nome = request.form.get('nome')
        produto.descricao = request.form.get('descricao')
        produto.preco = int(request.form.get('preco', 0))
        produto.estado = request.form.get('estado')
        produto.marca = request.form.get('marca')
        produto.modelo = request.form.get('modelo')
        produto.armazenamento = request.form.get('armazenamento')
        produto.cor = request.form.get('cor')

        if 'imagem' in request.files:
            file = request.files['imagem']
            if file and file.filename and allowed_file(file.filename):
                produto.imagem = save_image(file)

        db.session.commit()
        flash('Produto atualizado!', 'success')
        return redirect(url_for('seller.dashboard'))

    return render_template('seller/add_product.html', produto=produto)


@seller_bp.route('/produto/apagar/<int:id>')
@login_required
@vendedor_required
def delete_product(id):
    produto = Product.query.get_or_404(id)
    if produto.vendedor_id != current_user.id:
        flash('Não tens permissão.', 'danger')
    else:
        produto.ativo = False
        db.session.commit()
        flash('Produto removido.', 'info')
    return redirect(url_for('seller.dashboard'))


@seller_bp.route('/mensagens')
@login_required
@vendedor_required
def messages():
    # Agrupar conversas por remetente
    from app.models.user import User
    from sqlalchemy import distinct
    remetentes_ids = db.session.query(distinct(Message.remetente_id)).filter_by(
        destinatario_id=current_user.id).all()
    conversas = []
    for (rid,) in remetentes_ids:
        cliente = User.query.get(rid)
        ultima = Message.query.filter_by(
            remetente_id=rid, destinatario_id=current_user.id
        ).order_by(Message.criado_em.desc()).first()
        nao_lidas = Message.query.filter_by(
            remetente_id=rid, destinatario_id=current_user.id, lida=False).count()
        conversas.append({'cliente': cliente, 'ultima': ultima, 'nao_lidas': nao_lidas})

    return render_template('seller/messages.html', conversas=conversas)

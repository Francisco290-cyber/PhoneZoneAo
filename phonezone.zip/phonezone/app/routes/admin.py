from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.extensions import db
from app.models.user import User
from app.models.product import Product
from app.models.subscription import Subscription
from functools import wraps

admin_bp = Blueprint('admin', __name__)


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin():
            flash('Acesso restrito a administradores.', 'danger')
            return redirect(url_for('client.home'))
        return f(*args, **kwargs)
    return decorated


@admin_bp.route('/dashboard')
@login_required
@admin_required
def dashboard():
    total_clientes = User.query.filter_by(tipo='cliente').count()
    total_vendedores = User.query.filter_by(tipo='vendedor').count()
    total_produtos = Product.query.filter_by(ativo=True).count()
    subs_pendentes = Subscription.query.filter_by(ativa=False).count()
    return render_template('admin/dashboard.html',
                           total_clientes=total_clientes,
                           total_vendedores=total_vendedores,
                           total_produtos=total_produtos,
                           subs_pendentes=subs_pendentes)


@admin_bp.route('/vendedores')
@login_required
@admin_required
def sellers():
    vendedores = User.query.filter_by(tipo='vendedor').order_by(User.criado_em.desc()).all()
    return render_template('admin/sellers.html', vendedores=vendedores)


@admin_bp.route('/subscricao/aprovar/<int:id>')
@login_required
@admin_required
def approve_subscription(id):
    sub = Subscription.query.get_or_404(id)
    sub.aprovar()
    sub.aprovada_por = current_user.id
    db.session.commit()
    flash(f'Subscrição de {sub.vendedor.nome} aprovada!', 'success')
    return redirect(url_for('admin.sellers'))


@admin_bp.route('/subscricoes')
@login_required
@admin_required
def subscriptions():
    subs = Subscription.query.order_by(Subscription.criado_em.desc()).all()
    return render_template('admin/subscriptions.html', subs=subs)


@admin_bp.route('/produto/destaque/<int:id>')
@login_required
@admin_required
def toggle_destaque(id):
    produto = Product.query.get_or_404(id)
    produto.destaque = not produto.destaque
    db.session.commit()
    estado = 'em destaque' if produto.destaque else 'sem destaque'
    flash(f'Produto agora está {estado}.', 'info')
    return redirect(url_for('admin.dashboard'))


@admin_bp.route('/utilizadores')
@login_required
@admin_required
def users():
    todos = User.query.order_by(User.criado_em.desc()).all()
    return render_template('admin/users.html', users=todos)

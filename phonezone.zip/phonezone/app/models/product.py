from app.extensions import db
from datetime import datetime


class Product(db.Model):
    __tablename__ = 'products'

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150), nullable=False)
    descricao = db.Column(db.Text)
    preco = db.Column(db.Integer, nullable=False)  # em Kz
    estado = db.Column(db.String(20), default='usado')  # novo / usado
    imagem = db.Column(db.String(200))
    marca = db.Column(db.String(50))
    modelo = db.Column(db.String(100))
    armazenamento = db.Column(db.String(30))  # ex: 128GB
    cor = db.Column(db.String(30))
    destaque = db.Column(db.Boolean, default=False)
    aprovado = db.Column(db.Boolean, default=True)
    ativo = db.Column(db.Boolean, default=True)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    # Chave estrangeira
    vendedor_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

    def preco_formatado(self):
        return f"{self.preco:,} Kz".replace(',', '.')

    def __repr__(self):
        return f'<Product {self.nome}>'

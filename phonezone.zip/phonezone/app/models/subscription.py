from app.extensions import db
from datetime import datetime, timedelta


class Subscription(db.Model):
    __tablename__ = 'subscriptions'

    id = db.Column(db.Integer, primary_key=True)
    valor = db.Column(db.Integer, nullable=False)  # em Kz
    ativa = db.Column(db.Boolean, default=False)
    data_inicio = db.Column(db.DateTime)
    data_fim = db.Column(db.DateTime)
    comprovativo = db.Column(db.String(200))  # ficheiro do comprovativo
    aprovada_por = db.Column(db.Integer, db.ForeignKey('users.id'))
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    vendedor_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

    def aprovar(self):
        self.ativa = True
        self.data_inicio = datetime.utcnow()
        self.data_fim = datetime.utcnow() + timedelta(days=30)

    def __repr__(self):
        return f'<Subscription {self.id} vendedor={self.vendedor_id}>'

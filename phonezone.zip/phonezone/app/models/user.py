from app.extensions import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime


class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    telefone = db.Column(db.String(20))
    password_hash = db.Column(db.String(256), nullable=False)
    tipo = db.Column(db.String(20), default='cliente')  # cliente / vendedor / admin
    ativo = db.Column(db.Boolean, default=True)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    # Relações
    produtos = db.relationship('Product', backref='vendedor', lazy='dynamic')
    subscricoes = db.relationship('Subscription', backref='vendedor', lazy='dynamic')
    mensagens_enviadas = db.relationship('Message', foreign_keys='Message.remetente_id',
                                          backref='remetente', lazy='dynamic')
    mensagens_recebidas = db.relationship('Message', foreign_keys='Message.destinatario_id',
                                           backref='destinatario', lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def is_vendedor(self):
        return self.tipo == 'vendedor'

    def is_admin(self):
        return self.tipo == 'admin'

    def subscricao_ativa(self):
        sub = self.subscricoes.filter_by(ativa=True).first()
        return sub is not None

    def __repr__(self):
        return f'<User {self.email}>'


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

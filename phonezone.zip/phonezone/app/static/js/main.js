// Auto-dismiss flash messages
document.querySelectorAll('.alert').forEach(el => {
    setTimeout(() => el.style.opacity = '0', 4000);
    setTimeout(() => el.remove(), 4400);
    el.style.transition = 'opacity 0.4s';
});

// Image preview on upload
const uploadInput = document.querySelector('.upload-area input[type=file]');
const imgPreview = document.getElementById('img-preview');
if (uploadInput && imgPreview) {
    uploadInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const url = URL.createObjectURL(file);
            imgPreview.src = url;
            imgPreview.style.display = 'block';
        }
    });
}

// Tipo selector (register page)
document.querySelectorAll('.tipo-option').forEach(opt => {
    opt.addEventListener('click', () => {
        document.querySelectorAll('.tipo-option').forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');
        opt.querySelector('input').checked = true;
    });
});
